clear all
close all
clc
Fm=360;
Tm=1/Fm;
ECG=load('necg60.txt');
t=0:Tm:(length(ECG)/Fm)-Tm;
ECGR=ECG';
N=length(ECGR);
dF=Fm/N;
F=0:dF:(N-1)*dF;
tfs=fft(ECGR);
subplot(3,1,1);stem(F,abs(tfs),'m');xlabel('Frecuencia (Hz)');ylabel('Voltaje(V)');title('Dominio de la Frecuencia');
subplot(3,1,2);plot(t,ECGR,'c');xlabel('Tiempo (s)');ylabel('Voltaje(V)');title('Dominio del tiempo');
tfs((40 +dF)/dF:((180+dF)/dF))=0;
tfs((180+dF)/dF:(320+dF)/dF)=0;
sx=real(ifft(tfs));
subplot(3,1,3);plot(sx,'r');xlabel('Tiempo (s)');ylabel('Voltaje(V)');title('Dominio del tiempo');