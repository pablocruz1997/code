clear,clc,close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                  Mohamed BOUDIAF M'sila University
%                                02 2015
% Programme Principal de compression de signal ECG.
% Autor: Said BOUREZG  
% Electronics Engineer   Option:Communication .
% Date: 15.02.2015
% Adress:                          Said BOUREZG
%                               Elbassatine street
%                                 28038 Tarmount
%                               M'sila --- Algeria 
% Email:  said.bourezg@yahoo.fr
% Mobile: +213 796 018049 
% If you can improve this code furtherly, please let me know. Thanks
% Copyright @2015 Said BOUREZG.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compression Phase');
l_sig=10000;
Sig=ecg(l_sig) ;%ECG Data 
%----------------------------- DCT Transform -----------------------------% 
dct_Sig=dct(Sig);   %Discrete Cosin Transform of ECG   
%----------------------------- Thresholding ------------------------------%
Th=0.52;%Threshold value
Pos_th=find(abs(dct_Sig)<Th);
Sig_Afterthreshold=dct_Sig;
Sig_Afterthreshold(Pos_th)=0;
%----------------------------- Quantization ------------------------------%
Q=8;% 1 byte (value representation)
Max_SigAfter=max(Sig_Afterthreshold);
Min_SigAfter=min(Sig_Afterthreshold);
Sig_Quant=round((-1+2^Q)*(Sig_Afterthreshold-Min_SigAfter)/(Max_SigAfter-Min_SigAfter));
%-------------------------- Run Length Codising --------------------------%
Sig_RLE=rle(Sig_Quant);
RC=l_sig/(length(Sig_RLE)+2)%Compression Ratio
%-------------------------------------------------------------------------%
disp('D�compression Phase');
Sig_Irle=irle(Sig_RLE);% Inverse Run Length Codising 
Sig_IQuant=((Max_SigAfter-Min_SigAfter)/(-1+2^Q))*Sig_Irle+Min_SigAfter;% Inverse Quantization
Rec_Sig=idct(Sig_IQuant);%D�compressed Signal
%-------------------------- Method performance --------------------------%
Error=Sig-Rec_Sig;
SE=sum(Error.*Error);
PRD=sqrt(SE/sum(Sig.*Sig))
%-------------------------------------------------------------------------%
subplot(6,1,1),stem(Sig),subplot(6,1,2),stem(dct_Sig), 
subplot(6,1,3),plot(Sig_Afterthreshold),subplot(6,1,4),plot(Sig_Quant),subplot(6,1,5),stem(Rec_Sig),subplot(6,1,6),plot(Error),pause(6)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%